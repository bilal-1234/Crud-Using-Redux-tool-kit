import React from 'react'

export const UserList = [
    {
        name:"Bilal Ahmed khan",
        email: "bilalahmedkhan123@gmail.com",
        id: 1
    },
    {
        name:"ALi Ahmed khan",
        email: "aLiahmedkhan123@gmail.com",
        id: 2
    } ,
    {
        name:"Taij Ahmed khan",
        email: "Taijahmedkhan123@gmail.com",
        id: 3
    }    
]
